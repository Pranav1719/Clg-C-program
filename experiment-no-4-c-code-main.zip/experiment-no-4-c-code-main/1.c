#include <stdio.h>

int main() {
    int i;

    printf("Numbers from 1 to 10 using for loop:\n");
    for (i = 1; i <= 10; i++) 
    {
        printf("%d\n", i);
    }

    return 0;
}

#include <stdio.h>

int main() {
 int i;
 for(i=-5; i<=5; i++)
 
 if(i >= 0){
     printf("%d is positive\n", i);
}else{
     printf("%d is negative\n", i);
 } return 0 ;
}